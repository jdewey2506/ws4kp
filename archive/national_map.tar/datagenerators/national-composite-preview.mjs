import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import path from 'node:path';

const require = createRequire(import.meta.url);
const sharp = require('sharp');

const root = process.cwd();
const mapDir = path.join(root, 'server', 'images', 'maps');
const svgPath = path.join(mapDir, 'national-composite-preview.svg');
const pngPath = path.join(mapDir, 'national-composite-preview.png');

const svg = await fs.readFile(svgPath, 'utf8');
const overlaySvg = svg.replace(
	/\s*<rect width="1020" height="640" fill="#24345c"\/>\s*<image[\s\S]*?preserveAspectRatio="none"\/>\s*<rect width="1020" height="640" fill="#1f2445" opacity="0\.18"\/>/,
	'',
);

const overlay = await sharp(Buffer.from(overlaySvg)).png().toBuffer();

await sharp(path.join(mapDir, 'basemap.webp'))
	.resize(1020, 640, { fit: 'fill' })
	.modulate({ brightness: 0.72, saturation: 0.72 })
	.composite([{ input: overlay, top: 0, left: 0 }])
	.png()
	.toFile(pngPath);

console.log(`Wrote ${pngPath}`);
